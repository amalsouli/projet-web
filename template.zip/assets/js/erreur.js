function atelier4()
{
    //alert ("test");
    var n = document.getElementById("nomm").value;

    var erreur="<ul>";
       if(n[0] !== n[0].toUpperCase() || n.length == 0)
       {erreur+="<li> erreur nom !!</li>";}


       erreur+="</ul>";
       if(erreur == "<ul></ul>")
{
    alert();
}
document.getElementById("erreurlog").innerHTML=erreur;
}